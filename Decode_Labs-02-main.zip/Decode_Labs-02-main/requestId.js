'use strict';
const crypto = require('node:crypto');

// Step 1 of the pipeline. A client-supplied X-Request-Id is reused only if it
// is short and made of safe characters (never trust the client).
const SAFE = /^[A-Za-z0-9_-]{1,64}$/;

function newRequestId() {
  return 'req_' + crypto.randomBytes(4).toString('hex');
}

function resolveRequestId(headerValue) {
  return typeof headerValue === 'string' && SAFE.test(headerValue) ? headerValue : newRequestId();
}

module.exports = { resolveRequestId, newRequestId };
