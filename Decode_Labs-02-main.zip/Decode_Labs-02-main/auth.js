'use strict';

// Steps 3 and 4. AuthN answers "who are you?", AuthZ answers "what can you do?".
// Stateless: the key travels with every request, no session is stored.
function authenticate(req, keys) {
  const key = req.headers['x-api-key'];
  if (typeof key !== 'string') return null;
  const role = keys.get(key);
  return role ? { key, role } : null;
}

function authorize(role, allowedRoles) {
  return allowedRoles === 'public' || allowedRoles.includes(role);
}

module.exports = { authenticate, authorize };
