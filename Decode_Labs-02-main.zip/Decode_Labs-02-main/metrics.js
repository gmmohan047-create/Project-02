'use strict';

// Step 11. Records every response: status class, latency, throughput.
// Latency figures use the most recent RING_SIZE requests.
const RING_SIZE = 1000;

class Metrics {
  constructor({ now }) {
    this.now = now;
    this.startedAt = now();
    this.total = 0;
    this.classes = { '2xx': 0, '4xx': 0, '5xx': 0 };
    this.other = 0;
    this.rateLimited = 0;
    this.latencies = [];
    this.recent = []; // timestamps of the last 60 seconds
  }

  record({ status, latencyMs }) {
    this.total += 1;
    const cls = `${Math.floor(status / 100)}xx`;
    if (cls in this.classes) this.classes[cls] += 1;
    else this.other += 1;
    this.latencies.push(latencyMs);
    if (this.latencies.length > RING_SIZE) this.latencies.shift();
    const t = this.now();
    this.recent.push(t);
    this._prune(t);
  }

  recordRateLimited() {
    this.rateLimited += 1;
  }

  _prune(t) {
    while (this.recent.length && t - this.recent[0] > 60000) this.recent.shift();
  }

  snapshot() {
    const t = this.now();
    this._prune(t);
    const n = this.latencies.length;
    const sorted = [...this.latencies].sort((a, b) => a - b);
    const avg = n ? sorted.reduce((s, v) => s + v, 0) / n : 0;
    const p95 = n ? sorted[Math.ceil(0.95 * n) - 1] : 0;
    const r2 = (v) => Math.round(v * 100) / 100;
    // Availability = share of requests that did not end in a 5xx response.
    const availability = this.total ? ((this.total - this.classes['5xx']) / this.total) * 100 : 100;
    return {
      uptimeSeconds: Math.floor((t - this.startedAt) / 1000),
      totalRequests: this.total,
      statusBreakdown: { ...this.classes },
      avgLatencyMs: r2(avg),
      p95LatencyMs: r2(p95),
      requestsPerMinute: this.recent.length,
      availabilityPercent: r2(availability),
      rateLimited: this.rateLimited,
    };
  }
}

module.exports = { Metrics };
