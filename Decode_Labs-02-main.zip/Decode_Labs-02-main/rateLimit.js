'use strict';

// Step 2. Fixed-window limiter, one counter per identity (API key, or IP for
// unknown callers). State is in memory and resets on restart (documented trade-off).
class RateLimiter {
  constructor({ windowMs, max, now }) {
    this.windowMs = windowMs;
    this.max = max;
    this.now = now;
    this.buckets = new Map();
  }

  check(identity) {
    const t = this.now();
    if (this.buckets.size > 10000) this._purge(t);
    let b = this.buckets.get(identity);
    if (!b || t - b.start >= this.windowMs) {
      b = { start: t, count: 0 };
      this.buckets.set(identity, b);
    }
    b.count += 1;
    const allowed = b.count <= this.max;
    return {
      allowed,
      limit: this.max,
      remaining: Math.max(0, this.max - b.count),
      retryAfterSec: Math.max(1, Math.ceil((b.start + this.windowMs - t) / 1000)),
    };
  }

  _purge(t) {
    for (const [k, b] of this.buckets) if (t - b.start >= this.windowMs) this.buckets.delete(k);
  }
}

module.exports = { RateLimiter };
