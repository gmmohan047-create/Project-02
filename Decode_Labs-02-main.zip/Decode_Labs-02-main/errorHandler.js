'use strict';
const { ApiError } = require('../errors');

// Turns any thrown value into a clean JSON error. Unexpected errors become a
// generic 500: the real cause is logged, never leaked to the client.
function toErrorResponse(err, requestId, logError = console.error) {
  if (err instanceof ApiError) {
    const error = { code: err.code, message: err.message };
    if (err.details !== undefined) error.details = err.details;
    return { status: err.status, body: { error, requestId } };
  }
  logError(JSON.stringify({ level: 'error', requestId, message: err && err.message, stack: err && err.stack }));
  return {
    status: 500,
    body: { error: { code: 'INTERNAL_ERROR', message: 'An unexpected error occurred' }, requestId },
  };
}

module.exports = { toErrorResponse };
